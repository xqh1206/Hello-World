// miniprogram/page/component/pages/aria-component/aria-component.js
Page({
  onShareAppMessage() {
    return {
      title: '无障碍访问',
      path: 'page/component/pages/aria-component/aria-component'
    }
  },

})