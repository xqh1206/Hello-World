Page({
  onShareAppMessage() {
    return {
      title: '小程序组件文档',
      path: 'page/component/pages/doc-web-view/doc-web-view'
    }
  },
})
