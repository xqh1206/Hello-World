Page({
  data: {},
  onLoad() {},
  onShareAppMessage() {
    return {
      title: '换行排列',
      path: 'page/weui/example/linebreak/linebreak'
    }
  },
})
