Page({
  onShareAppMessage() {
    return {
      title: 'button',
      path: 'page/weui/example/button/button'
    }
  },
});