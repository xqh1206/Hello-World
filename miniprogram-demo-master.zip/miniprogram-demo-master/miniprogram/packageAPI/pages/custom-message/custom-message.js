Page({
  onShareAppMessage() {
    return {
      title: '客服消息',
      path: 'packageAPI/pages/custom-message/custom-message'
    }
  },
})
