Page({
  onShareAppMessage() {
    return {
      title: 'sendMessage',
      path: 'packageAPI/pages/sendMessage/sendMessage'
    }
  },
})
